<?php

require_once DIR_SYSTEM . 'library/ypmn/autoload.php';

use Ypmn\ApiRequest;
use Ypmn\Capture;
use Ypmn\Merchant;
use Ypmn\Product;
use Ypmn\Refund;

class ControllerExtensionPaymentYpmnTransactions extends Controller
{
	private $error = array();

	public function index()
	{
		if (!$this->user->hasPermission('access', 'extension/payment/ypmn/transactions')) {
			return new Action('error/permission');
		}
		$data = [];
		$this->load->language('extension/payment/ypmn');
		$this->load->model('extension/payment/ypmn');

		$this->document->setTitle($this->language->get('heading_title'));

		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}

		$url .= '&page=' . $page;

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		$data['sort_order']  = $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . '&sort=o.order_id' . $url, true);
		$data['sort_status'] = $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . '&sort=o.status' . $url, true);
		$data['sort_total']  = $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . '&sort=o.amount' . $url, true);
		$data['sort_date']   = $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . '&sort=o.date' . $url, true);

		$url .= '&sort=' . $sort;

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . $url, true),
		);

		$data['transactions'] = array();

		$filter_data = array(
			'filter_order_id' => $filter_order_id,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'           => $this->config->get('config_limit_admin'),
		);

		$order_total = $this->model_extension_payment_ypmn->getTotalTransactions($filter_data);

		$results = $this->model_extension_payment_ypmn->getTransactions($filter_data);

		foreach ($results as $result) {
			$info = [
				'status' => $result['payment_status'],
				'amount' => $result['amount'],
				'view'   => $this->url->link('sale/order/info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $result['order_id'] . $url, true),
				'edit'   => $this->url->link('sale/order/edit', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $result['order_id'] . $url, true),
				//'info'    => $this->url->link('extension/payment/ypmn/transactions/info', 'user_token=' . $this->session->data['user_token'] . '&order_id=' . $result['order_id'] . $url, true),
			];

			$info['infolink'] = $this->url->link('extension/payment/ypmn/transactions/info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $result['merchant_payment_reference'] . $url, true);

			$result                 = array_merge($result, $info);
			$data['transactions'][] = $result;
		}

		$data['button_settings'] = $this->language->get('text_settings');
		$data['settings_link']   = $this->url->link('extension/payment/ypmn', 'user_token=' . $this->session->data['user_token'], 'SSL');

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list']          = $this->language->get('text_list');
		$data['text_no_results']    = $this->language->get('text_no_results');
		$data['text_confirm']       = $this->language->get('text_confirm');
		$data['text_missing']       = $this->language->get('text_missing');
		$data['text_loading']       = $this->language->get('text_loading');
		$data['text_refund_action'] = $this->language->get('text_refund_action');

		$data['column_order_id']       = $this->language->get('column_order_id');
		$data['column_status']         = $this->language->get('column_status');
		$data['column_total']          = $this->language->get('column_total');
		$data['column_action']         = $this->language->get('column_action');
		$data['column_prepaid']        = $this->language->get('column_prepaid');
		$data['column_payment_status'] = $this->language->get('column_payment_status');

		$data['entry_order_id'] = $this->language->get('entry_order_id');

		$data['button_invoice_print']  = $this->language->get('button_invoice_print');
		$data['button_shipping_print'] = $this->language->get('button_shipping_print');
		$data['button_add']            = $this->language->get('button_add');
		$data['button_edit']           = $this->language->get('button_edit');
		$data['button_delete']         = $this->language->get('button_delete');
		$data['button_filter']         = $this->language->get('button_filter');
		$data['button_view']           = $this->language->get('button_view');
		$data['button_ip_add']         = $this->language->get('button_ip_add');
		$data['text_ip_add']           = sprintf($this->language->get('text_ip_add'), $this->request->server['REMOTE_ADDR']);

		$data['user_token'] = $this->session->data['user_token'];

		$pagination        = new Pagination();
		$pagination->total = $order_total;
		$pagination->page  = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url   = $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array) $this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$data['filter_order_id'] = $filter_order_id;
		$data['sort']            = $sort;
		$data['order']           = $order;

		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];

			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}

		$this->response->setOutput($this->load->view('extension/payment/ypmn_transactions', $data));
	}

	public function info()
	{
		$this->load->language('extension/payment/ypmn');
		$id  = $this->request->get['id'];
		$res = $this->db->query("SELECT * FROM `" . DB_PREFIX . "ypmn` where merchant_payment_reference='" . $this->db->escape($id) . "'");

		$data                = [];
		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');
		$data['row']         = $res->row;
		if (!empty($data['row']['products'])) {
			$data['row']['products'] = json_decode($data['row']['products'], true);
		}
		$data['breadcrumbs'] = array();

		$data['refund_url']  = $this->url->link('extension/payment/ypmn/transactions/refund', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);
		$data['capture_url'] = $this->url->link('extension/payment/ypmn/transactions/capture', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);
		$data['cancel_url']  = $this->url->link('extension/payment/ypmn/transactions/cancel', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);
		$data['status_url']  = $this->url->link('extension/payment/ypmn/transactions/update_status', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);

		$data['check_status_url'] = str_replace('amp;', '', $this->url->link('extension/payment/ypmn/transactions/status', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true));

		$data['back'] = $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);

		$data['back_button'] = $this->language->get('text_back');

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'], true),
		);

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];

			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}

		$data['await'] = false;
		if (strpos($data['row']['payment_status'], "AWAIT") !== false) {
			$data['await'] = true;
		}

		$this->load->model('user/api');

		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

		if ($api_info && $this->user->hasPermission('modify', 'sale/order')) {
			$session = new Session($this->config->get('session_engine'), $this->registry);

			$session->start();

			$this->model_user_api->deleteApiSessionBySessionId($session->getId());

			$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);

			$session->data['api_id'] = $api_info['api_id'];

			$data['api_token'] = $session->getId();
		} else {
			$data['api_token'] = '';
		}

		$data['catalog'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;

		$this->response->setOutput($this->load->view('extension/payment/ypmn_info', $data));
	}

	public function refund()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];
		$query     = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		$refund = new Refund();
		$refund->setYpmnPaymentReference($query->row['payu_payment_reference']);

		$refund->setCurrency('RUB');

		$apiRequest = $this->getApi();

		$merchant = $this->getMerchant();
		$amount   = $this->request->post['amount'] ?? 0;

		$data = $this->request->post;

		$products = $query->row['products'];
		if ($products) {
			$refundAmount = 0;
			$receipt      = $refundReceipt      = json_decode($products, true);
			$refundItems  = [];
			foreach ($data['position'] as $id) {
				if (!$data['quantity'][$id]) {
					continue;
				}

				$item             = $refundReceipt[$id];
				$item['quantity'] = intval($data['quantity'][$id]);
				$receipt[$id]['quantity'] -= $item['quantity'];
				$refundAmount += $item['quantity'] * $item['unitPrice'];

				if ($receipt[$id]['quantity'] == 0) {
					unset($receipt[$id]);
				}

				$item['unitPrice'] = floatval($item['unitPrice']);
				$item['amount']    = $item['unitPrice'] * $item['quantity'];
				$refund->addProduct(new Product($item));
			}
			$products = json_encode($receipt);
			$amount   = $refundAmount;
		}

		$refund->setOriginalAmount($query->row['amount']);
		$refund->setAmount($amount);

		if ($this->logging) {
			$this->log->write('refund request = ' . $refund->jsonSerialize());
		}

		$responseData = $apiRequest->sendRefundRequest($refund);

		if ($this->logging) {
			$this->log->write('refund response = ' . json_encode($responseData));
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$result = [
				'products'                   => $products,
				'payment_status'             => 'AWAIT_REFUND',
				'merchant_payment_reference' => $query->row['merchant_payment_reference'],
			];
			$this->updateTransaction($result);
			$this->session->data['success'] = $this->language->get('text_operation_success');
		} else {
			$this->session->data['error_warning'] = $responseData['message'];
		}

		$this->response->redirect($this->url->link('extension/payment/ypmn/transactions/info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $query->row['merchant_payment_reference'], true), '301');
	}

	public function capture()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];

		$data  = $this->request->post;
		$query = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		$capture = new Capture();
		$capture->setYpmnPaymentReference($query->row['payu_payment_reference']);

		$capture->setCurrency('RUB');

		$merchant = $this->getMerchant();

		$products = $query->row['products'];

		$newProducts = [];

		if ($data['position']) {
			$amount  = 0;
			$receipt = json_decode($products, true);
			$items   = [];
			foreach ($data['position'] as $id) {
				if (!$data['quantity'][$id]) {
					continue;
				}
				$item             = $receipt[$id];
				$item['quantity'] = $data['quantity'][$id];
				$newProducts[]    = $item;
				$amount += $item['quantity'] * $item['unitPrice'];
			}
		}

		$capture->setOriginalAmount($query->row['amount']);
		$capture->setAmount($amount);

		$apiRequest = $this->getApi();

		if ($this->logging) {
			$this->log->write('capture request = ' . $capture->jsonSerialize());
		}

		$responseData = $apiRequest->sendCaptureRequest($capture);

		if ($this->logging) {
			$this->log->write('capture response = ' . json_encode($responseData));
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$result = [
				'payment_status'             => 'AWAIT_COMPLETE',
				'products'                   => json_encode($newProducts),
				'amount'                     => $amount,
				'merchant_payment_reference' => $query->row['merchant_payment_reference'],
			];
			$this->updateTransaction($result);
			$this->session->data['success'] = $this->language->get('text_operation_success');
		} else {
			$this->session->data['error_warning'] = $responseData['message'];
			if ($responseData['message'] === 'Order already confirmed') {
				$result = [
					'payment_status'             => 'COMPLETE',
					'merchant_payment_reference' => $query->row['merchant_payment_reference'],
				];
				$this->updateTransaction($result);
			}
		}

		$this->response->redirect($this->url->link('extension/payment/ypmn/transactions/info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $query->row['merchant_payment_reference'], true), '301');
	}

	public function cancel()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];
		$query     = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		$refund = new Refund();
		$refund->setYpmnPaymentReference($query->row['payu_payment_reference']);

		$refund->setCurrency('RUB');

		$apiRequest = $this->getApi();

		$merchant = $this->getMerchant();

		$refund->setOriginalAmount($query->row['amount']);
		$refund->setAmount($query->row['amount']);

		if ($this->logging) {
			$this->log->write('cancel request = ' . $refund->jsonSerialize());
		}

		$responseData = $apiRequest->sendRefundRequest($refund);

		if ($this->logging) {
			$this->log->write('cancel response = ' . json_encode($responseData));
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$result = [
				'payment_status'             => 'AWAIT_REVERSED',
				'merchant_payment_reference' => $query->row['merchant_payment_reference'],
			];
			$this->updateTransaction($result);
			$this->session->data['success'] = $this->language->get('text_operation_success');
		} else {
			$this->session->data['error_warning'] = $responseData['message'];
		}

		$this->response->redirect($this->url->link('extension/payment/ypmn/transactions/info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $query->row['merchant_payment_reference'], true), '301');
	}

	public function update_status()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];
		$query     = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		$apiRequest = $this->getApi();

		$responseData = $apiRequest->sendStatusRequest($query->row['merchant_payment_reference_active']);
		if ($this->logging) {
			$this->log->write('info response = ' . json_encode($responseData));
		}

		$responseData                   = json_decode((string) $responseData["response"], true);
		$this->session->data['success'] = $this->language->get('text_status_changed') . $responseData['paymentStatus'];
		$result                         = [
			'payment_status'             => $responseData['paymentStatus'],
			'merchant_payment_reference' => $query->row['merchant_payment_reference'],
		];

		$this->updateTransaction($result);

		$status = $this->convertStatus($responseData['paymentStatus']);

		$json['order_history_data'] = array(
			'notify'          => 0,
			'order_id'        => $query->row['order_id'],
			'order_status_id' => $status,
			'comment'         => '',
		);
		$json['success'] = true;

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));

		//$this->response->redirect($this->url->link('extension/payment/ypmn/transactions/info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $query->row['merchant_payment_reference'], true), '301');

	}

	private function convertStatus($paymentStatus)
	{
		$status = 0;

		if ($paymentStatus === 'COMPLETE') {
			$status = $this->config->get('payment_ypmn_order_status_id');
		}

		if ($paymentStatus === 'PAYMENT_AUTHORIZED') {
			$status = $this->config->get('payment_ypmn_order_hold_status_id');
		}

		if ($paymentStatus === 'REFUND') {
			$status = $this->config->get('payment_ypmn_order_refund_status_id');
		}

		if ($paymentStatus === 'REVERSED') {
			$status = $this->config->get('payment_ypmn_order_refund_status_id');
		}
		return $status;
	}

	public function status()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];
		$query     = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		if (strpos($query->row['payment_status'], "AWAIT_") === false) {
			$this->session->data['success'] = $this->language->get('text_status_changed') . $query->row['payment_status'];
			$this->response->addHeader('Content-Type: application/json');
			$status                     = $this->convertStatus($query->row['payment_status']);
			$json                       = ['updated' => 1];
			$json['order_history_data'] = array(
				'notify'          => 0,
				'order_id'        => $query->row['order_id'],
				'order_status_id' => $status,
				'comment'         => '',
			);
			$this->response->setOutput(json_encode($json));
			return;
		}

		$apiRequest = $this->getApi();

		$responseData = $apiRequest->sendStatusRequest($query->row['merchant_payment_reference_active']);
		if ($this->logging) {
			$this->log->write('info response = ' . json_encode($responseData));
		}

		$responseData = json_decode((string) $responseData["response"], true);

		$updated = 0;

		if (str_replace($responseData['paymentStatus'], '', $query->row['payment_status']) === 'AWAIT_') {
			$result = [
				'payment_status'             => $responseData['paymentStatus'],
				'merchant_payment_reference' => $query->row['merchant_payment_reference'],
			];
			$this->updateTransaction($result);
			$updated                        = 1;
			$this->session->data['success'] = $this->language->get('text_status_changed') . $responseData['paymentStatus'];
		}

		$this->response->addHeader('Content-Type: application/json');
		$json   = ['updated' => $updated];
		if ($updated) {
			$status = $this->convertStatus($responseData['paymentStatus']);
			$json['order_history_data'] = array(
				'notify'          => 0,
				'order_id'        => $query->row['order_id'],
				'order_status_id' => $status,
				'comment'         => '',
			);
		}

		$this->response->setOutput(json_encode($json));
	}

	protected function getMerchant()
	{
		$secretKey = html_entity_decode($this->config->get('payment_ypmn_secret_key'));
		$merchant  = new Merchant(
			$this->config->get('payment_ypmn_merchant_code'),
			$secretKey
		);
		return $merchant;
	}

	protected function getApi()
	{
		$merchant = $this->getMerchant();

		$apiRequest = new ApiRequest($merchant);

		if ($this->config->get('payment_ypmn_test_mode')) {
			$apiRequest->setSandboxMode();
		}
		return $apiRequest;
	}

	private function updateTransaction($data)
	{
		$data = array_intersect_key($data, array_flip([
			'merchant_payment_reference',
			'order_id',
			'order_number',
			'payu_payment_reference',
			'amount',
			'url',
			'payment_status',
			'payment_method',
			'date',
			'products',
		]));
		$db          = $this->db;
		$escapedData = array_map(function ($key, $item) use ($db) {
			return '`' . $key . '`="' . $db->escape($item) . '"';
		}, array_keys($data), $data);

		$this->db->query("UPDATE " . DB_PREFIX . "ypmn set " . implode(',', $escapedData) . " where merchant_payment_reference='" . $this->db->escape($data['merchant_payment_reference']) . "'");
	}

}
