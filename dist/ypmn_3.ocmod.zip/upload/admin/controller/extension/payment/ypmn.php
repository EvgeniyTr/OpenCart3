<?php

require_once DIR_SYSTEM . 'library/ypmn/autoload.php';

use Ypmn\Capture;
use Ypmn\Refund;
use Ypmn\Product;
use Ypmn\ApiRequest;
use Ypmn\Merchant;
use Ypmn\PaymentMethods;

class ControllerExtensionPaymentYpmn extends Controller
{
	private Log $log;
	private bool $logging;

	public function __construct($registry)
	{
		parent::__construct($registry);

		$this->log = new Log('ypmn.log');
		$this->logging = $this->config->get('payment_ypmn_logging') === '1';
	}

	public function index(): void
	{
		// Load language
		$this->load->language('extension/payment/ypmn');

		// Load settings
		$this->load->model('setting/setting');

		// Set document title
		$this->document->setTitle($this->language->get('heading_title'));
		$data = [];
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		}

		// If isset request to change settings
		if ($this->request->server['REQUEST_METHOD'] === 'POST') {

			// Edit settings
			$this->model_setting_setting->editSetting('payment_ypmn', $this->request->post);

			// Set success message
			$this->session->data['success'] = $this->language->get('text_success');

			// Return to extensions page
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', 'SSL'));
		}

		// Load default layout
		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		// Load language variables
		$data['heading_title']                = $this->language->get('heading_title');
		$data['text_edit']                    = $this->language->get('text_edit');
		$data['text_enabled']                 = $this->language->get('text_enabled');
		$data['text_disabled']                = $this->language->get('text_disabled');
		$data['text_all_zones']               = $this->language->get('text_all_zones');
		$data['help_total']                   = $this->language->get('help_total');
		$data['button_save']                  = $this->language->get('button_save');
		$data['button_cancel']                = $this->language->get('button_cancel');

		// Load breadcrumbs
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ypmn', 'user_token=' . $this->session->data['user_token'], true),
		);

		// Load action buttons urls
		$data['action'] = $this->url->link('extension/payment/ypmn', 'user_token=' . $this->session->data['user_token'], 'SSL');
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', 'SSL');

		$data['callback_link'] = HTTP_CATALOG . 'index.php?route=extension/payment/ypmn/callback';

		$data['vat_list'] = [
			0  => $this->language->get('text_vat_0'),
			5  => $this->language->get('text_vat_5'),
			7  => $this->language->get('text_vat_7'),
			10 => $this->language->get('text_vat_10'),
			20 => $this->language->get('text_vat_20'),
			22 => $this->language->get('text_vat_22'),
		];




		$data['payment_list'] = [
		''						        => $this->language->get('text_payment_method_page'),
		PaymentMethods::CCVISAMC        => $this->language->get('text_payment_method_ccvisamc'),
		PaymentMethods::FASTER_PAYMENTS => $this->language->get('text_payment_method_faster_payments'),
		PaymentMethods::BNPL            => $this->language->get('text_payment_method_bnpl'),
		PaymentMethods::INTCARD         => $this->language->get('text_payment_method_som'),
		PaymentMethods::SBERPAY         => $this->language->get('text_payment_method_sberpay'),
		PaymentMethods::TPAY            => $this->language->get('text_payment_method_tpay'),
		PaymentMethods::ALFAPAY         => $this->language->get('text_payment_method_alfapay'),
		];


		// Set default values for fields

		$settings = [
			'paymentname'            => $this->language->get('text_paymentname'),
			'merchant_code'          => '',
			'secret_key'             => '',
			'product_vat'            => 0,
			'delivery_vat'           => 0,
			'total'                  => '',
			'logging'                => 0,
			'product_list'           => 1,
			'payment_method'         => PaymentMethods::CCVISAMC,
			'test_mode'              => 1,
			'order_status_id'        => '5', //Complete
			'order_hold_status_id'   => '2', //Complete
			'order_refund_status_id' => '11', //Refunded
			'status'                 => 0,
			'sort_order'             => '',
			'geo_zone_id'             => 0,
		];

		foreach ($settings as $key => $default) {
			$data['entry_' . $key] = $this->language->get('entry_' . $key);

			if (isset($this->request->post['payment_ypmn_' . $key])) {
				$data['payment_ypmn_' . $key] = $this->request->post['payment_ypmn_' . $key];
			} elseif ($this->config->has('payment_ypmn_' . $key)) {
				$data['payment_ypmn_' . $key] = $this->config->get('payment_ypmn_' . $key);
			} else {
				$data['payment_ypmn_' . $key] = $default;
			}
		}

		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$this->load->model('localisation/geo_zone');

		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		$this->response->setOutput($this->load->view('extension/payment/ypmn', $data));
	}

	public function transaction_info()
	{
		$this->load->language('extension/payment/ypmn');
		$id  = $this->request->get['id'];
		$res = $this->db->query("SELECT * FROM `" . DB_PREFIX . "ypmn` where merchant_payment_reference='" . $this->db->escape($id) . "'");

		$data                = [];
		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');
		$data['row']         = $res->row;
		if (!empty($data['row']['products'])) {
			$data['row']['products'] = json_decode($data['row']['products'], true);
		}
		$data['breadcrumbs'] = array();

		$data['refund_url'] = $this->url->link('extension/payment/ypmn/transaction_refund', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);
		$data['capture_url'] = $this->url->link('extension/payment/ypmn/transaction_capture', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);
		$data['cancel_url'] = $this->url->link('extension/payment/ypmn/transaction_cancel', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);

		$data['back'] = $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . '&id=' . $id, true);

		$data['back_button'] = $this->language->get('text_back');

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ypmn', 'user_token=' . $this->session->data['user_token'], true),
		);
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];

			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}
		$this->response->setOutput($this->load->view('extension/payment/ypmn_info', $data));
	}

	public function transactions()
	{
		$this->load->language('extension/payment/ypmn');
/*
		if (!$this->user->hasPermission('access', 'extension/payment/ypmn')) {
			return new Action('error/permission');
		}*/
		$data = [];
		$this->load->language('extension/payment/ypmn');
		$this->load->model('extension/payment/ypmn');

		$this->document->setTitle($this->language->get('heading_title'));

		if (isset($this->request->get['filter_order_id'])) {
			$filter_order_id = $this->request->get['filter_order_id'];
		} else {
			$filter_order_id = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'o.order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_order_id'])) {
			$url .= '&filter_order_id=' . $this->request->get['filter_order_id'];
		}



		$url .= '&page=' . $page;

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		$tokenKey = 'user_token';

		$data['sort_order']  = $this->url->link('extension/payment/ypmn/transactions', $tokenKey . '=' . $this->session->data[$tokenKey] . '&sort=o.order_id' . $url, true);
		$data['sort_status'] = $this->url->link('extension/payment/ypmn/transactions', $tokenKey . '=' . $this->session->data[$tokenKey] . '&sort=o.payment_status' . $url, true);
		$data['sort_total']  = $this->url->link('extension/payment/ypmn/transactions', $tokenKey . '=' . $this->session->data[$tokenKey] . '&sort=o.amount' . $url, true);
		$data['sort_date']  = $this->url->link('extension/payment/ypmn/transactions', $tokenKey . '=' . $this->session->data[$tokenKey] . '&sort=o.date' . $url, true);

		$url .= '&sort=' . $sort;

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $tokenKey . '=' . $this->session->data[$tokenKey], true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/ypmn', $tokenKey . '=' . $this->session->data[$tokenKey] . $url, true),
		);

		$data['transactions'] = array();

		$filter_data = array(
			'filter_order_id' => $filter_order_id,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * intval($this->config->get('config_pagination_admin')),
			'limit'           => $this->config->get('config_pagination_admin'),
		);

		$order_total = $this->model_extension_payment_ypmn->getTotalTransactions($filter_data);

		$results = $this->model_extension_payment_ypmn->getTransactions($filter_data);

		foreach ($results as $result) {
			$info = [
				'status' => $result['payment_status'],
				'amount' => $result['amount'],
				'view'   => $this->url->link('sale/order.info', $tokenKey . '=' . $this->session->data[$tokenKey] . '&order_id=' . $result['order_id'] . $url, true),
				'edit'   => $this->url->link('sale/order.edit', $tokenKey . '=' . $this->session->data[$tokenKey] . '&order_id=' . $result['order_id'] . $url, true),
			];

			$info['infolink'] = $this->url->link('extension/payment/ypmn/transaction_info', $tokenKey . '=' . $this->session->data[$tokenKey] . '&id=' . $result['merchant_payment_reference'] . $url, true);

			$result                 = array_merge($result, $info);
			$data['transactions'][] = $result;
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list']          = $this->language->get('text_list');
		$data['text_no_results']    = $this->language->get('text_no_results');
		$data['text_confirm']       = $this->language->get('text_confirm');
		$data['text_missing']       = $this->language->get('text_missing');
		$data['text_loading']       = $this->language->get('text_loading');
		$data['text_refund_action'] = $this->language->get('text_refund_action');

		$data['column_order_id']       = $this->language->get('column_order_id');
		$data['column_status']         = $this->language->get('column_status');
		$data['column_total']          = $this->language->get('column_total');
		$data['column_action']         = $this->language->get('column_action');
		$data['column_prepaid']        = $this->language->get('column_prepaid');
		$data['column_payment_status'] = $this->language->get('column_payment_status');

		$data['entry_order_id'] = $this->language->get('entry_order_id');

		$data['button_invoice_print']  = $this->language->get('button_invoice_print');
		$data['button_shipping_print'] = $this->language->get('button_shipping_print');
		$data['button_add']            = $this->language->get('button_add');
		$data['button_edit']           = $this->language->get('button_edit');
		$data['button_delete']         = $this->language->get('button_delete');
		$data['button_filter']         = $this->language->get('button_filter');
		$data['button_view']           = $this->language->get('button_view');

		$data['user_token'] = $this->session->data[$tokenKey];

		$data['pagination'] = $this->load->controller('common/pagination', [
			'total' => $order_total,
			'page'  => $page,
			'limit' => $this->config->get('config_pagination_admin'),
			'url'   => $this->url->link('extension/payment/ypmn/transactions', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}'),
		]);


		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array) $this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$data['filter_order_id'] = $filter_order_id;
		$data['sort']            = $sort;
		$data['order']           = $order;

		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];

			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}

		$data['catalog'] = $this->request->server['HTTPS'] ? $this->config->get('HTTPS_CATALOG') : HTTP_CATALOG;

		$this->response->setOutput($this->load->view('extension/payment/ypmn_transactions', $data));
	}



	public function transaction_refund()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];
		$query     = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		$refund = new Refund();
		$refund->setYpmnPaymentReference($query->row['payu_payment_reference']);

		$refund->setCurrency('RUB');

		$apiRequest = $this->getApi();

		$merchant = $this->getMerchant();
		$amount  = $this->request->post['amount'] ?? 0;

		$data = $this->request->post;

		$products = $query->row['products'];
		if ($products) {
			$refundAmount = 0;
			$receipt      = $refundReceipt      = json_decode($products, true);
			$refundItems  = [];
			foreach ($data['position'] as $id) {
				if (!$data['quantity'][$id]) {
					continue;
				}

				$item        = $refundReceipt[$id];
				$item['quantity'] = intval($data['quantity'][$id]);
				$receipt[$id]['quantity'] -= $item['quantity'];
				$refundAmount += $item['quantity'] * $item['unitPrice'];

				if ($receipt[$id]['quantity'] == 0) {
					unset($receipt[$id]);
				}

				$item['unitPrice'] = floatval($item['unitPrice']);
				$item['amount'] = $item['unitPrice'] * $item['quantity'];
				$refund->addProduct(new Product($item));
			}
			$products                      = json_encode($receipt);
			$amount = $refundAmount;
		}

		$refund->setOriginalAmount($query->row['amount']);
		$refund->setAmount($amount);

		if($this->logging) {
			$this->log->write('refund request = '.$refund->jsonSerialize());
		}

		$responseData = $apiRequest->sendRefundRequest($refund);

		if($this->logging) {
			$this->log->write('refund response = '.json_encode($responseData));
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$result = [
				'products' => $products,
				//'payment_status' => 'REFUND',
				'merchant_payment_reference' => $query->row['merchant_payment_reference'],
			];
			$this->updateTransaction($result);
			$this->session->data['success'] = $this->language->get('text_operation_success');
		} else {
			$this->session->data['error_warning'] = $responseData['message'];
		}

		$this->response->redirect($this->url->link('extension/payment/ypmn/transaction_info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $query->row['merchant_payment_reference'], true), '301');
	}

	public function transaction_capture()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];
		$query     = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		$capture = new Capture();
		$capture->setYpmnPaymentReference($query->row['payu_payment_reference']);

		$capture->setCurrency('RUB');

		$merchant = $this->getMerchant();

		$capture->setOriginalAmount($query->row['amount']);
		$capture->setAmount($query->row['amount']);

		$apiRequest = $this->getApi();

		if($this->logging) {
			$this->log->write('capture request = '.$capture->jsonSerialize());
		}

		$responseData = $apiRequest->sendCaptureRequest($capture);

		if($this->logging) {
			$this->log->write('capture response = '.json_encode($responseData));
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$result = [
				'payment_status' => 'COMPLETE',
				'merchant_payment_reference' => $query->row['merchant_payment_reference'],
			];
			$this->updateTransaction($result);
			$this->session->data['success'] = $this->language->get('text_operation_success');
		} else {
			$this->session->data['error_warning'] = $responseData['message'];
		}

		$this->response->redirect($this->url->link('extension/payment/ypmn/transaction_info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $query->row['merchant_payment_reference'], true), '301');
	}


	public function transaction_cancel()
	{
		$this->load->language('extension/payment/ypmn');
		$requestId = $this->request->get['id'];
		$query     = $this->db->query("
			SELECT *
			FROM `" . DB_PREFIX . "ypmn`
			WHERE merchant_payment_reference='" . $this->db->escape($requestId) . "'");
		$refund = new Refund();
		$refund->setYpmnPaymentReference($query->row['payu_payment_reference']);

		$refund->setCurrency('RUB');

		$apiRequest = $this->getApi();

		$merchant = $this->getMerchant();


		$refund->setOriginalAmount($query->row['amount']);
		$refund->setAmount($query->row['amount']);

		if($this->logging) {
			$this->log->write('cancel request = '.$refund->jsonSerialize());
		}

		$responseData = $apiRequest->sendRefundRequest($refund);

		if($this->logging) {
			$this->log->write('cancel response = '.json_encode($responseData));
		}

		$responseData = json_decode((string) $responseData["response"], true);

		if ($responseData['status'] === 'SUCCESS') {
			$result = [
				'payment_status' => 'REVERSED',
				'merchant_payment_reference' => $query->row['merchant_payment_reference'],
			];
			$this->updateTransaction($result);
			$this->session->data['success'] = $this->language->get('text_operation_success');
		} else {
			$this->session->data['error_warning'] = $responseData['message'];
		}

		$this->response->redirect($this->url->link('extension/payment/ypmn/transaction_info', 'user_token=' . $this->session->data['user_token'] . '&id=' . $query->row['merchant_payment_reference'], true), '301');
	}

	protected function getMerchant()
	{
		$secretKey = html_entity_decode($this->config->get('payment_ypmn_secret_key'));
		$merchant = new Merchant(
			$this->config->get('payment_ypmn_merchant_code'),
			$secretKey
		);
		return $merchant;
	}

	protected function getApi()
	{
		$merchant = $this->getMerchant();

		$apiRequest = new ApiRequest($merchant);

		if ($this->config->get('payment_ypmn_test_mode')) {
			$apiRequest->setSandboxMode();
		}
		return $apiRequest;
	}

	private function updateTransaction($data)
	{
		$data = array_intersect_key($data, array_flip([
			'merchant_payment_reference',
			'order_id',
			'order_number',
			'payu_payment_reference',
			'amount',
			'url',
			'payment_status',
			'payment_method',
			'date',
			'products',
		]));
		$db          = $this->db;
		$escapedData = array_map(function ($key, $item) use ($db) {
			return '`' . $key . '`="' . $db->escape($item) . '"';
		}, array_keys($data), $data);

		$this->db->query("UPDATE " . DB_PREFIX . "ypmn set " . implode(',', $escapedData) . " where merchant_payment_reference='" . $this->db->escape($data['merchant_payment_reference']) . "'");
	}

	public function install()
	{
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ypmn` (
		  `merchant_payment_reference` varchar(36) NOT NULL,
		  `order_id` INT NOT NULL,
		  `payu_payment_reference` varchar(25) NULL,
		  `amount` decimal(10,2) NOT NULL,
		  `url` varchar(500) NOT NULL,
		  `payment_status` varchar(150) NULL,
		  `payment_method` varchar(150) NULL,
		  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
		  `products` text,
		  `sandbox` INT,
		  `merchant_payment_reference_active` varchar(50) NULL,
		  PRIMARY KEY (`merchant_payment_reference`),
		  KEY `order_id` (`order_id`),
		  KEY `date` (`date`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8");

		$this->model_user_user_group->addPermission($this->user->getId(), 'access', 'extension/payment/ypmn/transactions');
		$this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'extension/payment/ypmn/transactions');

	}

	public function uninstall()
	{
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "ypmn`");
	}
}
